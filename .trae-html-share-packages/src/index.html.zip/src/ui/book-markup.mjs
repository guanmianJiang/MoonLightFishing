import {FISH,SPOTS,GEAR,SHOP} from '../data/catalog.mjs';
import {GAME_RULES} from '../config/game-rules.mjs';
import {saleValue} from '../reference-loop.mjs';
import {spotUnlocked} from '../engine.mjs';
import {explorationProgress} from '../progression-guide.mjs';
import {fishBehavior} from '../fish-behavior.mjs';
import {discoveryJournal} from '../discovery-notes.mjs';
import {spotChronicleView,waterChronicleCoverage} from '../spot-chronicle.mjs';
import {renderJournalOverview,renderEncounterAtlas} from './journal-achievements.mjs';

export function renderWaterChronicles(state){
 const coverage=waterChronicleCoverage(state),total=coverage.totalCasts;
 const cards=SPOTS.map(spot=>{
  const view=spotChronicleView(state,spot.id),unlocked=spotUnlocked(state,spot.id),current=state.spot===spot.id;
  const results=view.casts?`${view.casts} 竿 · 上岸 ${view.outcomes.landed} · 失手 ${view.outcomes.nearMiss} · 沉水物 ${view.outcomes.object} · 平静 ${view.outcomes.quiet}`:coverage.hasOlderCasts?'此版尚无逐竿记录':'尚未在这里抛竿';
  const fish=view.knownFish.length?`遇见：${view.knownFish.slice(0,3).map(item=>`${item.name} ${item.times} 次`).join(' · ')}`:'还没有上岸的鱼种记录';
  const action=unlocked&&!state.pending?`<button type="button" data-prepare-spot="${spot.id}">${current?'按建议选落点':'前往并选落点'}</button>`:'';
  return `<article class="spot-chronicle ${current?'current':''} ${unlocked?'':'locked'}"><div class="spot-chronicle__head"><span>${spot.chapter}</span><h4>${spot.name}</h4></div><strong>${unlocked?results:`探索 ${explorationProgress(state)} / ${spot.unlock} 开放`}</strong><p>${unlocked?(view.latest||view.theme):view.theme}</p>${unlocked?`<small>${fish}</small><small>下次可试：${view.next}</small>`:''}${action}</article>`;
 }).join('');
 return `<section class="spot-chronicle-section"><h3 class="section-title">水域履历 · 总共 ${total} 竿</h3>${coverage.hasOlderCasts?'<p class="book-note">旧记录缺少完整逐竿地点；下方地点履历从此版开始。</p>':''}<div class="spot-chronicle-list">${cards}</div></section>`;
}

export function renderBookMarkup(state,tab,thumb){
 if(tab==='atlas')return renderEncounterAtlas(state,thumb);
 let html='';

 if(tab==='basket'){const basket=state.economy.basket,total=basket.reduce((sum,c)=>sum+saleValue(c),0);html=`<div class="market-summary"><div><span>鱼篓 ${basket.length} / ${GAME_RULES.basketLimit}</span><strong>总价值 ${total} 金币</strong></div><button data-sell-all ${basket.length?'':'disabled'}>出售全部</button></div>`+(basket.length?`<div class="market-grid">${basket.map((c,i)=>{const f=FISH.find(x=>x.id===c.id);return `<article class="market-card"><div class="thumb" style="background-image:url('${thumb(c.id)}')"></div><span>${c.mutation||'普通'}</span><h3>${f?.name||'未知鱼获'}</h3><p>${c.weight.toFixed(2)} kg · ${c.variation||'本地鱼获'}</p><button data-sell="${i}">◎ ${saleValue(c)} · 出售</button></article>`}).join('')}</div>`:'<p class="empty">鱼篓还是空的。钓获后选择“放入鱼篓”，就能来这里出售。</p>');}
 if(tab==='shop'){html=`<div class="market-summary"><div><span>当前金币</span><strong>◎ ${state.economy.coins}</strong></div></div><div class="shop-grid">${SHOP.map(item=>{const level=state.economy.upgrades[item.id],price=item.prices[level];return `<article class="shop-card"><span>${item.name} · Lv. ${level+1} / 5</span><h3>${item.levels[level]}</h3><p>${item.description}</p><button data-upgrade="${item.id}" ${level>=4||state.economy.coins<price?'disabled':''}>${level>=4?'已满级':`◎ ${price} · 升级至 ${item.levels[level+1]}`}</button></article>`}).join('')}</div>`;}
 if(tab==='collection'){html=`<div class="collection-head"><div><strong>${state.collection.length} / ${GAME_RULES.collectionLimit}</strong><span>收藏位</span></div><p>收藏会占用位置并结束个体追踪；把活体放回水域后，可重新加入追踪名单。</p></div>`+(state.collection.length?`<div class="collection-grid">${state.collection.map((c,i)=>{const f=FISH.find(x=>x.id===c.id);return `<article class="collection-card"><div class="thumb" style="background-image:url('${thumb(c.id)}')"></div><h3>${f.name}${c.mutation?`<span class="badge">${c.mutation}</span>`:''}</h3><p>${c.weight.toFixed(3)} kg · ${c.variation}</p><button data-return="${i}">放回水域</button></article>`}).join('')}</div>`:'<p class="empty">当前没有收藏。<br>钓获后选择“收进收藏”即可保存样本。</p>');}
 if(tab==='water'){const goal=state.trip.goal,rule=state.trip.rule;html=renderWaterChronicles(state)+`<div class="water-progress"><strong>探索进度 ${explorationProgress(state)} · 调查进度 ${state.knowledge}</strong><span>每 2 次钓获增加探索：近岸最多 +3，外湾最多 +4；做成记录可额外推进，也能解锁钓组。</span></div><article class="water-row"><div><span>第 ${state.trip.number} 轮目标</span><h3>${goal.name}</h3></div><strong>${goal.progress} / ${goal.target}</strong></article><article class="water-row event"><div><span>当前水域事件 · 已触发 ${rule.triggers||0} 次</span><h3>${rule.name}</h3><p>${rule.desc}</p></div></article>`;
  const discoveries=discoveryJournal(state);
  if(discoveries.length)html+=`<h3 class="section-title">水域观察</h3>${discoveries.map(note=>`<article class="water-row"><div><span>${note.stateLabel}</span><h3>${note.title}</h3><p>${note.body}</p></div></article>`).join('')}`;
  html+=`<h3 class="section-title">追踪名单 ${state.tracked.length} / 3</h3>${state.tracked.length?state.tracked.map(x=>{const f=FISH.find(y=>y.id===x.id),spot=SPOTS.find(y=>y.id===x.spot);return `<article class="water-row tracked"><div><span>${spot?.name||'未知钓点'} · 已放流 ${x.releases} 次</span><h3>${f.name}</h3><p>上次重量 ${x.weight.toFixed(3)} kg，再次出现时会继续增重。</p></div><strong>追踪中</strong></article>`}).join(''):'<p class="empty compact">还没有追踪个体。放回活体后会自动加入。</p>'}<h3 class="section-title">当前鱼群状态</h3><div class="ecology">${Object.entries(state.ecosystem).map(([id,v])=>{const f=FISH.find(x=>x.id===id);return `<p><span>${f.name}</span><i><b style="width:${Math.min(100,v/2.5*100)}%"></b></i><em>${v>1.2?'较多':v<.8?'较少':'正常'}</em></p>`}).join('')}</div>`;}
 if(tab==='gear'){html=`<p class="book-note">不同钓组会调整可钓目标、鱼口观察和结果范围。达到调查进度要求后即可装备。</p>`+Object.entries(GEAR).map(([slot,items])=>`<section class="gear-section"><h3>${{rod:'鱼竿',reel:'线轮',line:'钓线',float:'浮漂'}[slot]}</h3>${items.map(item=>{const unlocked=state.knowledge>=item.unlock,equipped=state.gear[slot]===item.id;return `<button class="gear-item ${equipped?'equipped':''}" data-gear-slot="${slot}" data-gear="${item.id}" ${unlocked?'':'disabled'}><strong>${item.name}${equipped?' · 已装备':''}</strong><small>${unlocked?item.desc:`需要调查进度 ${item.unlock}`}</small></button>`}).join('')}</section>`).join('');}
 if(tab==='clues'){const observations=(state.observations||[]).slice(0,10);html=`<p class="book-note">观察漂相和鱼线，等鱼真正咬实再提竿。下方保留旧版本的鱼口记录；新的技巧表现见搏鱼手记。</p>`+(observations.length?`<section class="field-notes">${observations.map(o=>`<p class="${o.success?'right':o.forgiven?'saved':'wrong'}"><span>${o.success?`正确 · ${o.streak} 连段`:o.forgiven?'前期容错':'判断错误'}</span>${o.text}</p>`).join('')}</section>`:'<p class="empty">这里暂时没有旧版记录。新的鱼口不需要选择答案。</p>');}
 if(tab==='clues'){
  const learned=FISH.filter(f=>!f.object&&state.fightRecords[f.id]);
  html+=`<h3 class="section-title">搏鱼手记</h3><p class="book-note">每种鱼有自己的发力节奏。观察预兆，冲刺时松线，真正回气再抬竿；再次钓到同种鱼可以刷新技巧纪录。</p>`;
  html+=learned.length?learned.map(f=>{const b=fishBehavior(f.id),r=state.fightRecords[f.id];return `<article class="water-row"><div><span>${b.habit} · ${b.tell}</span><h3>${f.name}</h3><p>${b.counter}</p></div><strong>${r.grade} · ${r.cleanRuns}/${r.runsSeen} 次让线</strong></article>`}).join(''):'<p class="empty compact">钓上一尾鱼后，这里会留下它的习性和你的最佳搏鱼表现。</p>';
 }
  return tab==='water'?renderJournalOverview(state,thumb)+`<details class="journal-water-details"><summary>水域履历、追踪与本轮目标 <span>展开详细手记</span></summary>${html}</details>`:html;
}

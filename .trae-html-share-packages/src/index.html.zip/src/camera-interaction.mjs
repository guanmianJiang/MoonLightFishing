export function cameraStage(state,phase){
 if(state.overview)return 'overview';
 if(state.aiming&&!state.pending)return 'aim';
 if(state.revealing)return 'landing';
 if(state.pending?.fight?.status==='active')return 'fight';
 if(phase==='casting')return 'casting';
 if(['approach','reading','responding','nibble','hooked'].includes(phase))return 'bite';
 if(state.pending)return 'waiting';
 return 'survey';
}

export function castNeedsAimCamera(overview){
 return !overview;
}

export function readyWaterGesture(pointerCount,travelPx){
 if(pointerCount>=2)return 'pinch';
 return pointerCount===1&&Number.isFinite(travelPx)&&travelPx>7?'select':'wait';
}

export function aimCameraFocusPoint(selected,gesture){
 const anchor=gesture?.dragging?gesture.originPoint:null;
 return Array.isArray(anchor)&&anchor.length===2&&anchor.every(Number.isFinite)?anchor:selected;
}

export function visibleCastRanges(state,spotIds){
 if(!state||state.pending||state.catchProcessEvent||!Array.isArray(spotIds))return [];
 if(state.overview||!state.keepFishingView&&!state.aiming)return [...spotIds];
 return spotIds.includes(state.spot)?[state.spot]:[];
}

export function viewTransitionWeight(age,duration){
 if(!Number.isFinite(age)||!Number.isFinite(duration)||duration<=0)return 1;
 const t=Math.max(0,Math.min(1,age/duration));
 return t*t*t*(t*(t*6-15)+10);
}

export function portraitCloseFraming(rangeBlend,aiming){
 const t=Math.max(0,Math.min(1,rangeBlend));
 return {
  side:(aiming?2.1:1.9)-t*.5,
  aimMix:(aiming?.23:.17)+t*(aiming?.19:.13)
 };
}

export function cameraSettled(position,aim,targetPosition,targetAim,blend){
 return blend>.975&&position.distanceTo(targetPosition)<.9&&aim.distanceTo(targetAim)<.45;
}

export function cameraImpulse(age,duration){
 if(!Number.isFinite(age)||!Number.isFinite(duration)||age<=0||age>=duration||duration<=0)return 0;
 return Math.sin(Math.PI*age/duration);
}

export function cameraViewMode(state={}){
 if(state.overview)return 'overview';
 if(state.pending?.fight?.status==='active')return 'fight';
 return state.pending||state.aiming||state.keepFishingView?'close':'overview';
}

export const CAMERA_ANGLE_LIMITS=Object.freeze({
 overview:Object.freeze({yaw:[-1.2,1.2],pitch:[.58,1.47],defaultYaw:.16,defaultPitch:1.02}),
 close:Object.freeze({yaw:[-.30,.30],pitch:[-.12,.22],defaultYaw:0,defaultPitch:0}),
 fight:Object.freeze({yaw:[-.58,.58],pitch:[-.22,.28],defaultYaw:0,defaultPitch:0})
});

export function adjustCameraAngles(mode,angles={},deltaYaw=0,deltaPitch=0){
 const limits=CAMERA_ANGLE_LIMITS[mode]||CAMERA_ANGLE_LIMITS.overview;
 const bound=(key,delta)=>Math.max(limits[key][0],Math.min(limits[key][1],
  (Number.isFinite(angles[key])?angles[key]:limits[key==='yaw'?'defaultYaw':'defaultPitch'])+(Number.isFinite(delta)?delta:0)));
 return {yaw:bound('yaw',deltaYaw),pitch:bound('pitch',deltaPitch)};
}
